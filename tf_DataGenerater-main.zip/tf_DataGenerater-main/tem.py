"""
用于生成bat命令，先运行timber.bat
"""
for i in range(20):
    print(r'DataGenerater_humanpose_20220703_walk.py -m intel\human-pose-estimation-0001\FP16\human-pose-estimation-0001.xml -at openpose -i Videos\timberDataset-1\walk({}).mp4'.format(i))
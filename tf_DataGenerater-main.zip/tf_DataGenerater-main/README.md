# tf_DataGenerater
人体摔倒检测，完整代码见tf_Proj_predict20220624


# 环境
* Python3.6 
* tensorflow2

# 下载
* [source+Videos](https://pan.baidu.com/s/1No-ta1-BXrBUj4H5AYhdhA ) 提取码：4v8s 
* [tf_Proj_predict20220624](https://pan.baidu.com/s/15ZoReSQVGioQ_xqpCfyRYQ) 提取码：xan3
